# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
import numbers # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component
try:
    from dash.development.base_component import ComponentType # noqa: F401
except ImportError:
    ComponentType = typing.TypeVar("ComponentType", bound=Component)


class FlashEcharts(Component):
    """A FlashEcharts component.
DashECharts is a Dash component for rendering ECharts visualizations.
It wraps the ECharts library to provide an easy-to-use interface for creating
interactive charts in Dash applications.

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- className (string; default ''):
    The class name for the chart container.

- height (number | string; optional):
    The height of the chart container. If not specified, it will
    default to 400px.

- lastClickData (dict; optional):
    The last clicked data point, set by the component when a data
    point is clicked.

- lazyUpdate (boolean; default False):
    Whether to update immediately.

- loading (boolean; default False):
    Whether to show the loading animation. Same as showLoading.

- loadingOption (dict; optional):
    Configuration for the loading animation.

- notMerge (boolean; default False):
    If True, the specified option will not be merged with previous
    option.

- onEvents (dict; optional):
    Event handlers for the chart. Object with event names as keys and
    callback functions as values. Example: { 'click': (params) => {
    console.log(params); } }.

- option (dict; required):
    The ECharts option configuration for the chart. This is the main
    configuration object for the chart.

- renderer (a value equal to: 'canvas', 'svg'; default 'canvas'):
    The renderer type to use for the chart, 'canvas' or 'svg'.

- setOptionOpts (dict; optional):
    Configuration options for the setOption method.

- showLoading (boolean; default False):
    Whether to show the loading animation. Same as loading.

- theme (string | dict; optional):
    The theme to be applied to the chart. Can be the name of a
    built-in theme or a custom theme object.

- width (number | string; optional):
    The width of the chart container. If not specified, it will use
    the container's width."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'flash_echarts'
    _type = 'FlashEcharts'

    _explicitize_dash_init = True

    def __init__(
        self,
        id: typing.Optional[typing.Union[str, dict]] = None,
        className: typing.Optional[str] = None,
        style: typing.Optional[typing.Any] = None,
        option: typing.Optional[dict] = None,
        theme: typing.Optional[typing.Union[str, dict]] = None,
        renderer: typing.Optional[Literal["canvas", "svg"]] = None,
        width: typing.Optional[typing.Union[typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex], str]] = None,
        height: typing.Optional[typing.Union[typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex], str]] = None,
        onEvents: typing.Optional[dict] = None,
        loading: typing.Optional[bool] = None,
        loadingOption: typing.Optional[dict] = None,
        notMerge: typing.Optional[bool] = None,
        lazyUpdate: typing.Optional[bool] = None,
        setOptionOpts: typing.Optional[dict] = None,
        showLoading: typing.Optional[bool] = None,
        lastClickData: typing.Optional[dict] = None,
        **kwargs
    ):
        self._prop_names = ['id', 'className', 'height', 'lastClickData', 'lazyUpdate', 'loading', 'loadingOption', 'notMerge', 'onEvents', 'option', 'renderer', 'setOptionOpts', 'showLoading', 'style', 'theme', 'width']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'height', 'lastClickData', 'lazyUpdate', 'loading', 'loadingOption', 'notMerge', 'onEvents', 'option', 'renderer', 'setOptionOpts', 'showLoading', 'style', 'theme', 'width']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['option']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(FlashEcharts, self).__init__(**args)
