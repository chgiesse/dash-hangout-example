# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
import numbers # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component
try:
    from dash.development.base_component import ComponentType # noqa: F401
except ImportError:
    ComponentType = typing.TypeVar("ComponentType", bound=Component)


class FlashAdvancedEcharts(Component):
    """A FlashAdvancedEcharts component.
AdvancedDashECharts is an extension of the basic DashECharts component
with additional features like data preprocessing, responsive handling,
and animation control.

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- animation (boolean; default True):
    Whether to enable animation.

- animationDelay (number; default 0):
    Delay before animation starts in milliseconds. Can be a function:
    function (idx) { return idx * 100; }.

- animationDuration (number; default 1000):
    Duration of the animation in milliseconds.

- animationEasing (string; default 'cubicOut'):
    Easing method used for the animation.

- animationThreshold (number; default 2000):
    Data threshold for animation. Animation will be disabled when the
    number of elements exceeds this threshold.

- appendData (list of dicts; optional):
    Data to append to existing series. Format: [{ seriesIndex: 0,
    data: [newData] }, ...].

    `appendData` is a list of dicts with keys:

    - seriesIndex (number; required)

    - data (list; required)

- brushData (dict; optional):
    The last event data, set by the component when an event is
    triggered.

- className (string; default ''):
    The class name for the chart container.

- data (list | dict; optional):
    The data to be visualized. This will be processed by the
    dataProcessor function.

- height (number | string; optional):
    The height of the chart container. If not specified, it will
    default to 400px.

- lastEventData (dict; optional):
    The last event data, set by the component when an event is
    triggered.

- lazyUpdate (boolean; default False):
    Whether to update immediately.

- legendSelectedData (dict; optional):
    The last event data, set by the component when an event is
    triggered.

- loading (boolean; default False):
    Whether to show the loading animation. Same as showLoading.

- loadingOption (dict; optional):
    Configuration for the loading animation.

- notMerge (boolean; default False):
    If True, the specified option will not be merged with previous
    option.

- onEvents (dict; optional):
    Event handlers for the chart. Object with event names as keys and
    callback functions as values. Example: { 'click': (params) => {
    console.log(params); } }.

- option (dict; required):
    The ECharts option configuration for the chart. This is the main
    configuration object for the chart.

- prependData (list of dicts; optional):
    Data to prepend to existing series. Format: [{ seriesIndex: 0,
    data: [newData] }, ...].

    `prependData` is a list of dicts with keys:

    - seriesIndex (number; required)

    - data (list; required)

- renderer (a value equal to: 'canvas', 'svg'; default 'canvas'):
    The renderer type to use for the chart, 'canvas' or 'svg'.

- selectedData (dict; optional):
    The last event data, set by the component when an event is
    triggered.

- setOptionOpts (dict; optional):
    Configuration options for the setOption method.

- showLoading (boolean; default False):
    Whether to show the loading animation. Same as loading.

- theme (string | dict; optional):
    The theme to be applied to the chart. Can be the name of a
    built-in theme or a custom theme object.

- width (number | string; optional):
    The width of the chart container. If not specified, it will use
    the container's width.

- zoomData (dict; optional):
    The last event data, set by the component when an event is
    triggered."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'flash_echarts'
    _type = 'FlashAdvancedEcharts'
    AppendData = TypedDict(
        "AppendData",
            {
            "seriesIndex": typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex],
            "data": typing.Sequence
        }
    )

    PrependData = TypedDict(
        "PrependData",
            {
            "seriesIndex": typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex],
            "data": typing.Sequence
        }
    )

    _explicitize_dash_init = True

    def __init__(
        self,
        id: typing.Optional[typing.Union[str, dict]] = None,
        className: typing.Optional[str] = None,
        style: typing.Optional[typing.Any] = None,
        option: typing.Optional[dict] = None,
        data: typing.Optional[typing.Union[typing.Sequence, dict]] = None,
        appendData: typing.Optional[typing.Sequence["AppendData"]] = None,
        prependData: typing.Optional[typing.Sequence["PrependData"]] = None,
        dataProcessor: typing.Optional[typing.Any] = None,
        theme: typing.Optional[typing.Union[str, dict]] = None,
        renderer: typing.Optional[Literal["canvas", "svg"]] = None,
        width: typing.Optional[typing.Union[typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex], str]] = None,
        height: typing.Optional[typing.Union[typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex], str]] = None,
        onEvents: typing.Optional[dict] = None,
        loading: typing.Optional[bool] = None,
        loadingOption: typing.Optional[dict] = None,
        notMerge: typing.Optional[bool] = None,
        lazyUpdate: typing.Optional[bool] = None,
        setOptionOpts: typing.Optional[dict] = None,
        showLoading: typing.Optional[bool] = None,
        animation: typing.Optional[bool] = None,
        animationDuration: typing.Optional[typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex]] = None,
        animationEasing: typing.Optional[str] = None,
        animationDelay: typing.Optional[typing.Union[typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex], typing.Any]] = None,
        animationThreshold: typing.Optional[typing.Union[typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex]] = None,
        lastEventData: typing.Optional[dict] = None,
        selectedData: typing.Optional[dict] = None,
        brushData: typing.Optional[dict] = None,
        legendSelectedData: typing.Optional[dict] = None,
        zoomData: typing.Optional[dict] = None,
        **kwargs
    ):
        self._prop_names = ['id', 'animation', 'animationDelay', 'animationDuration', 'animationEasing', 'animationThreshold', 'appendData', 'brushData', 'className', 'data', 'height', 'lastEventData', 'lazyUpdate', 'legendSelectedData', 'loading', 'loadingOption', 'notMerge', 'onEvents', 'option', 'prependData', 'renderer', 'selectedData', 'setOptionOpts', 'showLoading', 'style', 'theme', 'width', 'zoomData']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'animation', 'animationDelay', 'animationDuration', 'animationEasing', 'animationThreshold', 'appendData', 'brushData', 'className', 'data', 'height', 'lastEventData', 'lazyUpdate', 'legendSelectedData', 'loading', 'loadingOption', 'notMerge', 'onEvents', 'option', 'prependData', 'renderer', 'selectedData', 'setOptionOpts', 'showLoading', 'style', 'theme', 'width', 'zoomData']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['option']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(FlashAdvancedEcharts, self).__init__(**args)
